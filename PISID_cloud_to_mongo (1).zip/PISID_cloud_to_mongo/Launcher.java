import java.sql.SQLException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Launcher {
    private static ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    private static int currentExperimentID = 0;
    private static CloudToMongoConfig config = new CloudToMongoConfig("config.properties");
    private static boolean isConnected = false;
    private static SQLDatabaseManager sqlDatabaseManager ;


    public static void main(String[] args) {
        try {
            sqlDatabaseManager = new SQLDatabaseManager(config.getSqlURL(), config.getSqlUsername(), config.getSqlPassword());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        MongoDatabaseManager mongoTemperatureCollection = new MongoDatabaseManager(config.getMongoURI());
        MongoDatabaseManager mongoMovementCollection = new MongoDatabaseManager(config.getMongoURI());
        mongoTemperatureCollection.setCollection(config.getTemperatureCollection());
        mongoTemperatureCollection.setDatabase(config.getMongoDB());
        mongoMovementCollection.setCollection(config.getMovementCollection());
        mongoMovementCollection.setDatabase(config.getMongoDB());

        System.out.println("Starting experiment launcher...");
        ListenerMongo listenerMongoTemperature = new ListenerMongo(mongoTemperatureCollection);
        ListenerMongo listenerMongoMovement = new ListenerMongo(mongoMovementCollection);
        MQTTManager temperatureMQTTManager = new MQTTManager(config.getCloudURL(),config.getTemperatureCloudTopic(),listenerMongoTemperature);
        MQTTManager movementMQTTManager = new MQTTManager(config.getCloudURL(),config.getMovementCloudTopic(),listenerMongoMovement);




    scheduler.scheduleAtFixedRate(() -> {
        try {
            currentExperimentID = sqlDatabaseManager.getLatestExperienciaID();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


        if (currentExperimentID == 0 && isConnected) {
            isConnected = false;
            temperatureMQTTManager.DisconnectCloud();
            movementMQTTManager.DisconnectCloud();
            System.out.println("No experiment running, disconnecting from cloud");
        }
        if (currentExperimentID != 0 && !isConnected) {
            isConnected = true;
            System.out.println("Experiment with id " + currentExperimentID + " running, connecting to cloud");
            temperatureMQTTManager.ConnectCloud();
            movementMQTTManager.ConnectCloud();
        }
    }, 0, 1, TimeUnit.SECONDS);

    }

}