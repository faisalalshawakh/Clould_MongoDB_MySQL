import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;

import java.time.Duration;
import java.time.Instant;
import java.util.Date;

public class MongoDatabaseManager {

    private MongoClient mongoClient;
    private MongoDatabase database;
    private String mongoURI;
    private String dbName;
    private String collectionName;
    private boolean isConnected;

    public MongoDatabaseManager(String mongoURI) {
        this.mongoURI = mongoURI;
        connect() ;
    }

    public MongoDatabase getDatabase(String dbName) {
        if (this.database == null) {
            this.database = mongoClient.getDatabase(dbName);
        }
        return this.database;
    }

    public MongoCollection<Document> getCollection() {
        return getDatabase(dbName).getCollection(collectionName);
    }

    public Bson getLastHourFilter() {
        Instant oneHourAgo = Instant.now().minus(Duration.ofHours(1));
        ObjectId oneHourAgoObjectId = new ObjectId(Date.from(oneHourAgo));
        return Filters.gte("_id", oneHourAgoObjectId);
    }

    public Bson getGreaterThanIdFilter(String lastID) {
        ObjectId lastObjectId = new ObjectId(lastID);
        return Filters.gt("_id", lastObjectId);
    }

    public void closeConnection() {
        if (this.mongoClient != null) {
            this.mongoClient.close();
            this.isConnected = false;
        }
    }

    public void insertDocument(Document doc) {
        try {
            getCollection().insertOne(doc);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setDatabase(String dbName) {
        this.dbName = dbName;
    }
    public void setCollection(String collectionName) {
        this.collectionName = collectionName;
    }

    public void connect() {
        if (this.mongoClient == null ) {
            this.mongoClient = MongoClients.create(mongoURI);
            this.isConnected = true;
        }
    }

    public boolean isConnected() {
        return this.isConnected;
    }
}
