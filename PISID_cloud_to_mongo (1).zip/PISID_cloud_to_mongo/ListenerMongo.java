import org.bson.Document;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class ListenerMongo implements MQTTMessageListener{
    MongoDatabaseManager mongoDatabaseManager;
    ListenerMongo(MongoDatabaseManager mongoDatabaseManager){
        this.mongoDatabaseManager = mongoDatabaseManager;
    }
    @Override
    public void messageReceived(String topic, MqttMessage message) {
        try {
            InsertMessage(message.toString());
        } catch (Exception e) {
            System.err.println("Invalid message: " + message.toString());
        }
    }

    private void InsertMessage(String message) throws Exception {
        Document doc = Document.parse(message);
        System.out.println("Inserting document: " + doc.toJson());
        mongoDatabaseManager.insertDocument(doc);
    }
}
