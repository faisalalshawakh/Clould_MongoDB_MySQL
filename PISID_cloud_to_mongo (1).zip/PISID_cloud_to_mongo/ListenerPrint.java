import org.eclipse.paho.client.mqttv3.MqttMessage;

public class ListenerPrint implements MQTTMessageListener{
@Override
    public void messageReceived(String topic, MqttMessage message) {
        System.out.println("Topic: " + topic);
        System.out.println("Message received: " + message.toString());
    }
}
