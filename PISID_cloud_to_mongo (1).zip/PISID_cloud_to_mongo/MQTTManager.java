import org.eclipse.paho.client.mqttv3.*;

import java.util.Random;


public class MQTTManager implements MqttCallback {

    private String cloud_server;
    private String cloud_topic;
    private MQTTMessageListener listener;
    private MqttClient mqttclient;
    MQTTManager(String cloud_server, String cloud_topic, MQTTMessageListener listener){
        this.cloud_server = cloud_server;
        this.cloud_topic = cloud_topic;
        this.listener = listener;
    }


    @Override
    public void connectionLost(Throwable throwable) {

    }

    @Override
    public void messageArrived(String s, MqttMessage mqttMessage) throws Exception {
        if (listener != null)
            listener.messageReceived(s, mqttMessage);

    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {

    }

    public boolean ConnectCloud(){
        int i;
        try {
            i = new Random().nextInt(100000);
            mqttclient = new MqttClient(cloud_server, "CloudToMongo_" + i + "_" + cloud_topic);
            mqttclient.connect();
            mqttclient.setCallback(this);
            mqttclient.subscribe(cloud_topic);
            return true;
        } catch (MqttException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean DisconnectCloud(){
        try {
            mqttclient.disconnect();
            return true;
        } catch (MqttException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean isConnected() {
        return mqttclient.isConnected();
    }
}
