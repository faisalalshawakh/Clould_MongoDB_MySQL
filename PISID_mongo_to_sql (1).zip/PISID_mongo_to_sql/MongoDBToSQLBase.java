import com.mongodb.client.*;
import org.bson.Document;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Optional;
import java.util.Scanner;

public abstract class MongoDBToSQLBase {

    protected int cooldownBetweenFiles;
    protected MongoToSQLConfig config;

    public MongoDBToSQLBase(String configFile) {
        config = new MongoToSQLConfig(configFile);
        cooldownBetweenFiles = config.getCooldownBetweenFiles();

    }

    public abstract void startTransfer() throws SQLException, ClassNotFoundException, InterruptedException, IOException;

    public int IDtoInt(String collection) {
        int IdMongo = Integer.parseInt(collection, 16);
        return IdMongo;
    }

    public String getLastDocumentTimeStamp(MongoCollection<Document> collection) {
        Document last = collection.find().sort(new Document("_id", -1)).limit(1).first();
        String timeStamp = last.get("Hora").toString();
        return timeStamp;
    }

    public void saveIDs(String DocumentID, String filename) throws IOException {
        FileWriter writer = new FileWriter(filename);
        writer.write(DocumentID + "\n");
        writer.close();
        System.out.println("Restart file '" + filename + "' created with ID '" + DocumentID + "'.");
    }

    public boolean checkInactivity(MongoCollection<Document> collection, Integer secondsCooldown) throws InterruptedException {
        String lastTimeStamp = getLastDocumentTimeStamp(collection);
        if (lastTimeStamp.length() > 23) {
            lastTimeStamp = lastTimeStamp.substring(0, 23);
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS", Locale.ENGLISH);
        LocalDateTime lastTime = LocalDateTime.parse(lastTimeStamp, formatter);
        LocalDateTime currentTime = LocalDateTime.now();

        long secondsElapsed = Duration.between(lastTime, currentTime).getSeconds();

        return secondsElapsed >= secondsCooldown;
    }

    public Optional<String> getRestartFileId(String filename) {
        File file = new File(filename);
        if (!file.exists()) {
            return Optional.empty();
        }

        try (Scanner scanner = new Scanner(file)) {
            if (scanner.hasNextLine()) {
                String id = scanner.nextLine();
                return Optional.of(id);
            } else {
                return Optional.empty();
            }
        } catch (IOException e) {
            throw new RuntimeException("Error reading restart file: " + filename, e);
        }
    }
}