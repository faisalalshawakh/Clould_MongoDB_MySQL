import java.sql.SQLException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ExperienceLauncher {

    private static SQLDatabaseManager sqlDatabaseManager ;
    private static MongoToSQLConfig config = new MongoToSQLConfig("config.properties");
    private static ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    private static int currentExperimentID = 0;
    private static boolean isConnected = false;



    public static void main(String[] args) throws SQLException {

        try {
            sqlDatabaseManager = new SQLDatabaseManager(config.getSqlURL(), config.getSqlUsername(), config.getSqlPassword());
        } catch (SQLException e) {
            e.printStackTrace();
        }

        MongoDBToSQLTemperatura mongoDBToSQLTemperatura = new MongoDBToSQLTemperatura("config.properties");
        Thread temperaturaThread = new Thread(mongoDBToSQLTemperatura);
        MongoDBToSQLMovimento mongoDBToSQLMovimento = new MongoDBToSQLMovimento("config.properties");
        Thread movimentoThread = new Thread(mongoDBToSQLMovimento);
        temperaturaThread.start();
        movimentoThread.start();


        scheduler.scheduleAtFixedRate(() -> {
            try {
                currentExperimentID = sqlDatabaseManager.getLatestExperienciaID();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

            if(!temperaturaThread.isAlive())
                temperaturaThread.start();

            if(!movimentoThread.isAlive())
                movimentoThread.start();


            if (currentExperimentID == 0 && isConnected) {
                isConnected = false;
                mongoDBToSQLTemperatura.disallowTransfer();
                mongoDBToSQLMovimento.disallowTransfer();
                System.out.println("Experiencia Terminada, parando transferência");
            }
            if (currentExperimentID != 0 && !isConnected) {
                isConnected = true;
                System.out.println("Experiencia com id " + currentExperimentID + " activa, começando transferência");
                mongoDBToSQLTemperatura.allowTransfer();
                mongoDBToSQLMovimento.allowTransfer();
            }
        }, 0, 1, TimeUnit.SECONDS);





        // Schedule the experiment status task
}

}
