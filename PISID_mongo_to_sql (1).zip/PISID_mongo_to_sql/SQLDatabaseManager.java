import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class SQLDatabaseManager {

    private String sqlURL;
    private String username;
    private String password;
    private Connection conn;

    public SQLDatabaseManager(String sqlURL, String username, String password) throws SQLException {
        this.sqlURL = sqlURL;
        this.username = username;
        this.password = password;
        openConnection();
    }

    public void openConnection() throws SQLException {
        conn = DriverManager.getConnection(sqlURL, username, password);
    }

    public void closeConnection() throws SQLException {
        if (conn != null && !conn.isClosed()) {
            conn.close();
        }
    }

    public Connection getConnection() {
        return conn;
    }

    public int getLatestExperienciaID() throws SQLException {
        // Get the last document ID
        CallableStatement stmtGetIdExperiencia = conn.prepareCall("{? = call GetIdUltimaExperienciaIniciada(null)}");
        stmtGetIdExperiencia.registerOutParameter(1, Types.INTEGER);
        stmtGetIdExperiencia.execute();
        int idExperiencia = stmtGetIdExperiencia.getInt(1);
        stmtGetIdExperiencia.close();
        return idExperiencia;
    }

    public Map<String, Integer> getAtributosExperiencia(int id) throws SQLException {
        Map<String, Integer> atributos = new HashMap<>();

        PreparedStatement stmtGetAtributosExperiencia = conn.prepareStatement("SELECT nrSalas, SegundosSemMovimentos FROM experiencia WHERE IdExperiencia = ?");
        stmtGetAtributosExperiencia.setInt(1, id);

        ResultSet rs = stmtGetAtributosExperiencia.executeQuery();

        if (rs.next()) {
            atributos.put("nrSalas", rs.getInt("nrSalas"));
            atributos.put("SegundosSemMovimentos", rs.getInt("SegundosSemMovimentos"));
        }

        rs.close();
        stmtGetAtributosExperiencia.close();

        return atributos;
    }

    public void inserirMedicoesPassagem(int id, Timestamp hora, int salaEntrada, int salaSaida) throws SQLException {
        CallableStatement stmtInserirMedicoes = conn.prepareCall("{ ? = call AtualizarMedicoesPassagem(?, ?, ?, ?) }");
        stmtInserirMedicoes.setInt(2, id);
        stmtInserirMedicoes.setInt(3, salaSaida);
        stmtInserirMedicoes.setTimestamp(4, hora);
        stmtInserirMedicoes.setInt(5, salaEntrada);
        stmtInserirMedicoes.execute();
        stmtInserirMedicoes.close();
    }

    public void inserirMedicoesTemperatura(int id, int sensor, String hora, double temperatura) throws SQLException {
        CallableStatement stmtInserirMedicoes = conn.prepareCall("call InserirMedicoesTemperatura(?, ?, ?, ?)");
        stmtInserirMedicoes.setInt(1, id);
        stmtInserirMedicoes.setString(2, hora);
        stmtInserirMedicoes.setDouble(3, temperatura);
        stmtInserirMedicoes.setInt(4, sensor);

        stmtInserirMedicoes.execute();
        stmtInserirMedicoes.close();
    }

    public void terminarExperiencia(int experienciaId, char inatividade) throws SQLException {
        CallableStatement stmtTerminarExperiencia = conn.prepareCall("{call TerminarExperiencia(?, ?)}");
        stmtTerminarExperiencia.setInt(1, experienciaId);
        stmtTerminarExperiencia.setInt(2, inatividade);
        stmtTerminarExperiencia.execute();
        stmtTerminarExperiencia.close();
    }
}