import com.mongodb.client.*;
import org.bson.Document;
import org.bson.conversions.Bson;


import java.io.IOException;
import java.sql.*;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;

public class MongoDBToSQLTemperatura extends MongoDBToSQLBase implements Runnable{

    private String mongoURI;
    private String mongoDB;
    private Optional<String> lastID;
    private String sqlURL;
    private String sqlUsername;
    private String sqlPassword;
    private String collectionToCopy;
    private String restartFile = "restartTemp.ini";
    public SQLDatabaseManager sqlDatabaseManager;
    public MongoDatabaseManager mongoDatabaseManager;
    private MongoCollection<Document> collection;
    private final AtomicBoolean running = new AtomicBoolean(false);

    public MongoDBToSQLTemperatura(String configFile) throws SQLException {
        super(configFile);
        mongoURI = config.getMongoURI();
        mongoDB = config.getMongoDB();
        sqlURL = config.getSqlURL();
        sqlUsername = config.getSqlUsername();
        sqlPassword = config.getSqlPassword();
        collectionToCopy = config.getTemperatureCollection();
        sqlDatabaseManager = new SQLDatabaseManager(sqlURL, sqlUsername, sqlPassword);
        mongoDatabaseManager = new MongoDatabaseManager(mongoURI);
        mongoDatabaseManager.setDatabase(mongoDB);
        mongoDatabaseManager.setCollection(collectionToCopy);
        collection = mongoDatabaseManager.getCollection();


    }

    @Override
    public void run() {
        while (true) {
            if(running.get()){
                startTransfer();
            }            try {
                Thread.sleep(cooldownBetweenFiles);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void allowTransfer() {
        running.set(true);
    }

    public void disallowTransfer() {
        running.set(false);
    }

    @Override
    public void startTransfer() {

        lastID = getRestartFileId(restartFile);

        Bson filter;
        if (lastID.isPresent()) {
            filter = mongoDatabaseManager.getGreaterThanIdFilter(lastID.get());
        } else {
            filter = mongoDatabaseManager.getLastHourFilter();
        }

        try {

            int experienciaId = sqlDatabaseManager.getLatestExperienciaID();

            if (experienciaId > 0) {

                collection.find(filter).forEach(document -> {
                    if (document == null) {
                        return;
                    }

                    try {
                        System.out.println("Recebido temperatura: " + document.toJson());
                        saveIDs(document.get("_id").toString(), restartFile);

                        DataFilter df = new DataFilter(document.get("Hora").toString(), document.get("Leitura").toString(), (Integer) document.get("Sensor"));

                        if (df.validCheckSensor() || df.validCheckLeitura()) {
                            sqlDatabaseManager.inserirMedicoesTemperatura(experienciaId, (Integer) document.get("Sensor"), df.horaFilter(), (Double) document.get("Leitura"));
                        }else
                            System.out.println("TEMPERATURA: Documento não enviado, dados inválidos!");


                    } catch (SQLException e) {
                        try {
                            saveIDs(document.get("_id").toString(), restartFile);
                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        }
                        e.printStackTrace();
                    } catch (IOException e) {
                        try {
                            saveIDs(document.get("_id").toString(), restartFile);
                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        }
                        throw new RuntimeException(e);
                    }
                    catch (NullPointerException e) {
                        try {
                            saveIDs(document.get("_id").toString(), restartFile);
                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        }
                        System.out.println("TEMPERATURA: Documento não enviado, falta de dados!");
                    }
                    catch (ClassCastException e) {
                        try {
                            saveIDs(document.get("_id").toString(), restartFile);
                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        }
                        System.out.println("TEMPERATURA: Algum valor com tipo errado!");
                    }
                });

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
