import com.mongodb.client.MongoCollection;
import org.bson.Document;
import org.bson.conversions.Bson;
import java.io.IOException;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;

public class MongoDBToSQLMovimento extends MongoDBToSQLBase implements Runnable{

    private String mongoURI;
    private String mongoDB;
    private Optional<String> lastID;
    private String sqlURL;
    private String sqlUsername;
    private String sqlPassword;
    private String collectionToCopy;
    private  int nrSalas;
    private  int segundosSemMovimento;
    private String restartFile = "restartMov.ini";
    public SQLDatabaseManager sqlDatabaseManager;
    public MongoDatabaseManager mongoDatabaseManager;
    private MongoCollection<Document> collection;
    private final AtomicBoolean running = new AtomicBoolean(false);
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");


    public MongoDBToSQLMovimento(String configFile) throws SQLException {
        super(configFile);
        mongoURI = config.getMongoURI();
        mongoDB = config.getMongoDB();
        sqlURL = config.getSqlURL();
        sqlUsername = config.getSqlUsername();
        sqlPassword = config.getSqlPassword();
        collectionToCopy = config.getMovementCollection();
        sqlDatabaseManager = new SQLDatabaseManager(sqlURL, sqlUsername, sqlPassword);
        mongoDatabaseManager = new MongoDatabaseManager(mongoURI);
        mongoDatabaseManager.setDatabase(mongoDB);
        mongoDatabaseManager.setCollection(collectionToCopy);
        collection = mongoDatabaseManager.getCollection();
    }

    @Override
    public void run() {
        while (true) {

            if(running.get()){
                startTransfer();
            }
            try {
                Thread.sleep(cooldownBetweenFiles);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void allowTransfer() {
        running.set(true);
    }

    public void disallowTransfer() {
        running.set(false);
    }

    @Override
    public void startTransfer() {

        lastID = getRestartFileId(restartFile);

        Bson filter;
        if (lastID.isPresent()) {
            filter = mongoDatabaseManager.getGreaterThanIdFilter(lastID.get());
        } else {
            filter = mongoDatabaseManager.getLastHourFilter();
        }

        try {

            int experienciaId = sqlDatabaseManager.getLatestExperienciaID();

            if (checkInactivity(collection, segundosSemMovimento)) {
                sqlDatabaseManager.terminarExperiencia(experienciaId, 'Y');
                System.out.println("Movimento: Experiência terminada por inactividade!");
            }

            if (experienciaId > 0) {
                Map<String, Integer> atributosExperiencia = sqlDatabaseManager.getAtributosExperiencia(experienciaId);

                if (!atributosExperiencia.isEmpty()) {
                    nrSalas = atributosExperiencia.get("nrSalas");
                    segundosSemMovimento = atributosExperiencia.get("SegundosSemMovimentos");
                } else {
                    System.out.println("Movimento: Número de salas não encontrado.");
                }

                collection.find(filter).forEach(document -> {
                    //leave loop is document is null
                    if (document == null) {
                        return;
                    }

                    try {
                        System.out.println("Recebido Movimento : " + document.toJson());
                        saveIDs(document.get("_id").toString(), restartFile);

                        DataFilter df = new DataFilter(document.get("Hora").toString(), (Integer) document.get("SalaEntrada"), (Integer) document.get("SalaSaida"));
                        if (df.filterSala(nrSalas)) {
                            Timestamp data = new Timestamp(dateFormat.parse(df.horaFilter()).getTime());
                            sqlDatabaseManager.inserirMedicoesPassagem( experienciaId, data,(Integer) document.get("SalaEntrada"), (Integer) document.get("SalaSaida"));
                        }else
                            System.out.println("Movimento: Documento não enviado, sala inválida!");





                    } catch (SQLException e) {
                        try {
                            saveIDs(document.get("_id").toString(), restartFile);
                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        }
                        e.printStackTrace();
                    } catch (IOException e) {
                        try {
                            saveIDs(document.get("_id").toString(), restartFile);
                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        }
                        throw new RuntimeException(e);
                    } catch (ParseException e) {
                        System.out.println("Movimento: Data inválida!");
                    }
                    catch (NullPointerException e) {
                        try {
                            saveIDs(document.get("_id").toString(), restartFile);
                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        }
                        System.out.println("Movimento: Documento não enviado, falta de dados!");
                        throw new RuntimeException(e);
                    }
                });

            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }


}