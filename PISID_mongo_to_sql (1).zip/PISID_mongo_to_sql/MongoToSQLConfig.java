import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class MongoToSQLConfig {
    private Properties properties;

    public MongoToSQLConfig(String configFile) {
        properties = new Properties();
        try (FileInputStream input = new FileInputStream(configFile)) {
            properties.load(input);
        } catch (IOException e) {
            throw new RuntimeException("Error loading config file: " + configFile, e);
        }
    }

    public String getMongoURI() {
        return properties.getProperty("mongoURI");
    }

    public String getSqlURL() {
        return properties.getProperty("sqlURL");
    }

    public String getSqlUsername() {
        return properties.getProperty("sqlUsername");
    }

    public String getSqlPassword() {
        return properties.getProperty("sqlPassword");
    }

    public String getTemperatureCollection() {
        return properties.getProperty("temperatureCollection");
    }

    public String getMovementCollection() {
        return properties.getProperty("movementCollection");
    }

    public int getCooldownBetweenFiles() {
        return Integer.parseInt(properties.getProperty("cooldown"));
    }

    public String getMongoDB() {
        return properties.getProperty("mongoDB");
    }
}
