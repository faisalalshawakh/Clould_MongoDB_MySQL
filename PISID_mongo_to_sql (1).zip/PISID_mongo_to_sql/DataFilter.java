import java.time.LocalDate;
import java.time.LocalTime;

public class DataFilter {


    private String hora;
    private String leitura;
    private int sensor;
    private int salaEntrada;
    private int salaSaida;
    private boolean isDateWrong;


    public DataFilter(String hora, String leitura, int sensor) {
        this.hora = hora;
        this.leitura = leitura;
        this.sensor = sensor;
    }

    public DataFilter(String hora, int salaEntrada, int salaSaida){
        this.salaEntrada = salaEntrada;
        this.salaSaida = salaSaida;
        this.hora = hora;
    }


    public boolean validCheckLeitura() {

        String pattern = "[0-9]+(\\.[0-9]+)?\\.?";

        // Check if leitura matches the pattern
        if (leitura.matches(pattern)) {
            // Remove the trailing zero if it's an integer
            if (leitura.endsWith(".0")) {
                leitura = leitura.substring(0, leitura.length() - 2);
            }
            return true;
        } else {
            return false;
        }
    }


    public boolean filterSala(int nrSalas){

        if(salaEntrada < 1 || salaSaida < 0 || salaEntrada > nrSalas || salaSaida > nrSalas){
            return false;
        }

        return true;
    }

    public boolean validCheckSensor(){

        if(sensor == 1 || sensor == 2){

        return true;

        }

        return false;
    }

    public String horaFilter(){

        String[] horaParts = hora.split("[-\\s:]");
        String year = horaParts[0];
        String month = horaParts[1];
        String day = horaParts[2];
        String hour = horaParts[3];
        String minute = horaParts[4];
        String second = horaParts[5];

        LocalDate currentDate = LocalDate.now();
        LocalTime currentTime = LocalTime.now();

        //Check if date is wrong
        if(!(Integer.parseInt(year) == currentDate.getYear() && Integer.parseInt(month) == currentDate.getMonthValue() && Integer.parseInt(day) == currentDate.getDayOfMonth())){

           hora = LocalDate.now().toString() + " " + hour + ":" + minute + ":" + second;
           isDateWrong = true;

        }

        if(!(Integer.parseInt(hour) == currentTime.getHour())) {

            hora = LocalDate.now().toString() + " " + LocalTime.now().getHour() + ":" + minute + ":" + second;
            isDateWrong = true;

        }

        if(!(Integer.parseInt(minute) == currentTime.getMinute())) {

            hora = LocalDate.now().toString() + " " + LocalTime.now().getHour() + ":" + LocalTime.now().getMinute() + ":" + second;
            isDateWrong = true;

        }

        return hora;
    }


    public boolean getDateWrong(){
        return isDateWrong;
    }








}
